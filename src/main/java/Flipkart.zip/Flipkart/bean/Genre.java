package Flipkart.bean;

/**
 * Created by dakshay on 23/10/2021.
 */
public class Genre {

    private final String name;


    public Genre(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
