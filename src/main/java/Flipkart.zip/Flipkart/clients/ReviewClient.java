package Flipkart.clients;

import Flipkart.bean.Genre;
import Flipkart.bean.Movie;
import Flipkart.bean.User;
import Flipkart.dto.GenreDTO;
import Flipkart.helpers.GenreHelper;
import Flipkart.services.ReviewService;

import java.util.List;

/**
 * Created by dakshay on 23/10/2021.
 */
public class ReviewClient {

    private List<Movie> movies;
    private List<User> users;

    public Movie addMovie(String movieName, Long releaseYear, List<GenreDTO> genreDTO){
        List<Genre> genre = GenreHelper.convertToBean(genreDTO);
        Movie movie = new Movie(movieName,releaseYear,genre);
        this.movies.add(movie);
        return movie;
    }

    public User addUser(String name) {
        User user = new User(name, User.Judgement.VIEWER);
        this.users.add(user);
        return user;
    }

    public void makeReview(String userName, String movieName, int rating) {
        ReviewService reviewService = new ReviewService(movies,users);
        reviewService.createReview(userName,movieName,rating);
    }
}
