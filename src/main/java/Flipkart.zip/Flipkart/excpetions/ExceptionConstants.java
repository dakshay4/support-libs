package Flipkart.excpetions;

/**
 * Created by dakshay on 22/10/2021.
 */
public enum ExceptionConstants {
    MOVIE_YET_TO_BE_PUBLISHED,
    MULTIPLE_REVIEWS_NOT_ALLOWED;

}
