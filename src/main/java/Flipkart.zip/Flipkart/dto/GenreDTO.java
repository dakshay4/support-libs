package Flipkart.dto;

/**
 * Created by dakshay on 23/10/2021.
 */
public class GenreDTO {
    private final String name;

    public GenreDTO(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
